package com.se.tests.smoke;

import com.se.config.Constants;
import com.se.rolesbase.StudentLoginBase;
import com.se.utils.NavigationUtil;
import com.se.utils.UtilsSet;
import org.testng.Assert;
import org.testng.annotations.Test;

public class StudentAccountTest extends StudentLoginBase {


    @Test
    public void authenticStudentIsLoggedIn(){

        System.out.println("A Student is now logged in");
    }

    @Test(dependsOnMethods = "authenticStudentIsLoggedIn")

    public void verifyLearnButtonIsShowingCourses() {

        System.out.println("Starting verifyLearnButtonIsShowingCourses test");

        NavigationUtil.clickLearnButton();

        System.out.println("Learn, button is clicked");
        try{
            UtilsSet.waitForElementToBeVisible(Constants.learning.course_inTab, 30);
            String courses = UtilsSet.findElement(Constants.learning.course_inTab).getText();

            Assert.assertEquals(courses, "Courses", "Mismatch courses in tab");
            System.out.println("Course is visible with text in tab : " + courses);
        }catch(Exception e){
            System.out.println("exception is  : "+ e.getMessage());
        }

    }
    @Test(dependsOnMethods = "verifyLearnButtonIsShowingCourses")

    public void SubjectCollection() {

        System.out.println("Starting verifyLearnButtonIsShowingCourses test");

        NavigationUtil.subjectcollection();

        System.out.println("Course(COMPUTER SCIENCE) button is clicked");

        try{

        }catch(Exception e){
            System.out.println("exception is  : "+ e.getMessage());
        }

    }
    @Test(dependsOnMethods = "SubjectCollection")
    public void SelectSubject() {

        System.out.println("Starting verifyDataBAseButtonIsShowingInComputerScience test");

        NavigationUtil.selectsubject();

        System.out.println("data base button is clicked");

    }
    @Test(dependsOnMethods = "SelectSubject")
    public void SubscribeSubject() {

        System.out.println("Starting verifyLearnButtonIsShowing  test");

        NavigationUtil.clickOnsubscribe();

        System.out.println("Check Box is Selected");

    }
    @Test(dependsOnMethods = "SubscribeSubject")
    public void selectClass() {

        System.out.println("Starting verifyCheckBoxButtonIsShowingClassList test");

        NavigationUtil.selectClass();

        System.out.println("Check box is clicked");

    }

    @Test(dependsOnMethods = "selectClass")
    public void subscribedClass() {

        System.out.println("Starting verifySubscribeButtonIsShowing test");

        NavigationUtil.ClassSubscribed();

        System.out.println("Subscribe button is clicked");

    }

//    @Test(dependsOnMethods = "subscribedClass")
//    public void unsub(){
//        System.out.println("Starting verifySubscribeButtonIsShowing test");
//
//        NavigationUtil.Unsubscribeing();
//
//        System.out.println("Subscribe button is clicked");
//    }






}

